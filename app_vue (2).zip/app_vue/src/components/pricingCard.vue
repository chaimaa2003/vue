<template>
    <h1>{{ this.price.title }}</h1>
    <h2 v-for="spicification in this.price.spicifications">{{ spicification }}</h2>
</template>
<script>
    export default {
        name: "card",
        props: {
            price: Object
        }

    }
</script>
<style>


</style>
