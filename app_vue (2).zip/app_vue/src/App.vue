<template>


<Navbar/>
<pricingPage />

</template>

<script setup>
import Navbar from "./components/Navbar.vue";
import pricingPage from "./views/pricing.vue";


</script>




<style scoped>


</style>