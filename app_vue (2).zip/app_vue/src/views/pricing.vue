<template>
    
    <div class="prices" ><PricingCard v-for="price in prices" :price="price"/></div> 
</template>
<script>
import PricingCard from '../components/pricingCard.vue';

 export default{
    name: "pricingPage",
    components:{
        PricingCard
    },
    data(){
        return {

            prices:[{
                title:"Free",
                spicifications:[
                    "1",
                    "2",
                    "3"
                ]
                
            },
            {
                title:"$24",
                spicifications:[
                    "1",
                    "2",
                    "3"
                ]
                
            },
            {
                title:"$12",
                spicifications:[
                    "1",
                    "2",
                    "3"
                ]
                
            }]
        }
    }

 }
</script>
<style>
    .prices{
        margin-top: 30%;
    }
</style>