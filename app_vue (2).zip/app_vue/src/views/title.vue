<template>
    <h1></h1>
</template>
<script>
 export default{
    name:"titlePage",
    components:{
        
    }
 }

</script>
<style>
</style>